import { Parser } from "json2csv";
import * as fs from "fs";
import fetch from "node-fetch";

//columns in exported CSV file
const fields = [
  { label: "Item Group Id", value: "groupId" },
  { label: "Name", value: "name" },
  { label: "Price", value: "price" },
  { label: "GTIN", value: "gtin" }
];

//get group ids from CSV file
function arrayGroupIds() {
  var data = fs.readFileSync("groupids.csv", "utf8");
  data = data.split("\r\n"); // SPLIT ROWS
  data.shift();
  data.pop();
  return data;
}

async function totalIndividualItems() {
  const groupIds = arrayGroupIds();
  let arr = [];
  for (let i = 0; i < groupIds.length; i++) {
    let indiv = await getIndividualItems(groupIds[i]);
    arr.push(indiv);
  }
  return arr;
}

async function concatArrays() {
  const arr = await totalIndividualItems();
  let allItems = [];
  for (let i = 0; i < arr.length - 1; i++) {
    allItems = arr[i].concat(arr[i + 1]);
  }
  return allItems;
}

//call ebay API to get data of a group id
async function getIndividualItems(groupId) {
  const url = `https://api.ebay.com/buy/browse/v1/item/get_items_by_item_group?item_group_id=${groupId}`;
  const token =
    "v^1.1#i^1#f^0#p^1#I^3#r^0#t^H4sIAAAAAAAAAOVYW2wUVRjubi9YsRgTAwRv67SoEWZ2zsx2dndkV5ZuKUtpt2VrbYvSzOXsdtzdmWHmjKWawFojF20MiSQa5KEvIFGIlwQbExIRJAINIFDQB3nogwmJAUVihKDgmd2lbCvh1k1s4r5s5j//+c/3fef/z/ln6ExF5bPrlqz7s8oxzTmYoTNOhwNMpysryufNKHXOKS+hCxwcg5maTFl/6dkFppBO6fxyaOqaakLX6nRKNfmsMUBYhsprgqmYvCqkockjiY+FmpbxDEXzuqEhTdJShCsSDhAM5EAtCxhO9sicINHYql6P2aYFCIFlWYYBNA1oSfbK9rhpWjCimkhQEZ5PMwwJAAnoNobhaY5nWMrn8XURrnZomIqmYheKJoJZuHx2rlGA9dZQBdOEBsJBiGAktDgWDUXC9c1tC9wFsYJ5HWJIQJY5/qlOk6GrXUhZ8NbLmFlvPmZJEjRNwh3MrTA+KB+6DuYe4GellkUv4PwyHff4WMCyvqJIuVgz0gK6NQ7boshkPOvKQxUpqO92imI1xFeghPJPzThEJOyy/1otIaXEFWgEiPpFoc5QSwsRXKqIhqCGIZkwNEsnW5aHSRlwoiixPpYEXtHrEf21+VVyofIaT1imTlNlxVbMdDVraBHEkOF4YQBfWyAMdoqqUSMURzacMT/QRtNjAjJd9o7mttBCPaq9qTCNVXBlH28v/9hshAxFtBAcizBxIKsPrhldV2Ri4mA2EfO5s9oMED0I6bzb3dvbS/WylGYk3AyuMndH07KY1APTApHztWsd+yu3n0AqWSoSxDNNhUd9OsayGicqBqAmiKCH41jOk9d9PKzgROu/DAWc3ePLoVjl4eMEEcRZSZZEKPplrhjlEcxnqNvGAUWhj0wLRhIiPSVIkJRwnllpaCgyz9bGGdYXh6TM+eOkxx+Pk2KtzJEgDiENIc5kv+9/UyV3mucxKBkQFSvRi5Pk4YbOxmRtZ0NCBgkm3B5duqrRaH3xtVCsoaE+aoB62jtvFUzqrU1WMnCnpXBT8nUpBSvThtcvngB2rRdDhCWaiaA8KXoxSdNhi5ZSpL6ptcGsIbcIBuqLwVQKGyZFMqTrkaId1MWhdzdnxL2RLurt9F/cTDdlZdr5OrVY2fNNHEDQFcq+eyhJS7s1ATcdtsmu9e4s6knxVnDDOqVYY5I5toqc6zSpLGXKfFWiDGhqloGbbCpq915tWhKq+DJDhpZKQaMdTLqY02kLCWIKTrWqLkKCK8IUu2kBx/kA8Pp97KR4Sdl7tHuqHUlFPYfLnruLbto9/sU+WJL9gX7Hbrrf8bnT4aDd9FxQTT9ZUfpCWekDc0wFQUoR4pSpJFT8vmpAKgn7dEExnBWONU1866mCTwmDL9Ozxz4mVJaC6QVfFuhHb4yUgwdnVeH3fgBwt0hzDNtFV98YLQMzyx5eubnZ/9tHe1HHOf2bS5dGTyhPH26kq8acHI7ykrJ+Rwn75sgjW+6ve2hk7fA+V3D+6ZEt4S8PHbKE0Ce/Hl0hzf26Zvg9FP69cZNy5N2162uvnRk4I6yYfWrz6OxgDdM94O39eOf5GbOovaFk9X37P3DvuXDiU2vh0ZrExSs69dUJuLLqj67BH6I9Vw/Afu93oZPpkz9/v3F0qOOtnd9efmfWhi8W741Fe6qOXDj9esnGnw4eVErWX/N8CD4bOJYa0Bu6V/zVVb3u72Pbl740tGPajqHHLv7o3NCxaX9m8P3dj5+d98y0Pasqr26d+3b/moVR09F54I3R3qH2wFaJHxga3je8KxbbdezKE+S2bdHKrdsz556a+fyR+b90XB5NHh6JnO8+7rxcf/woLea27x8vt3FF5BEAAA==";

  const authString = "Bearer " + token;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Authorization": authString,
      "Content-Type": "application/json"
    }
  });
  const data = await response.json();
  const items = data.items;
  const newArray = items.map((item) => newItem(item));
  return newArray;
}

function newItem(item) {
  const itemData = {
    groupId: item.legacyItemId,
    name: item.localizedAspects[0].value,
    price: item.price.value,
    gtin: item.gtin
  };
  return itemData;
}

const allItems = await concatArrays();

const json2csvParser = new Parser({ fields });
const csv = json2csvParser.parse(allItems);
fs.writeFileSync("products.csv", csv);
